@import "common.js";

function Translator () {}

Translator.prototype.languageLabels = [
    'Bulgarian',
    'Czech',
    'Danish',
    'German',
    'Greek',
    'English',
    'Spanish',
    'Estonian',
    'Finnish',
    'French',
    'Hungarian',
    'Italian',
    'Japanese',
    'Lithuanian',
    'Latvian',
    'Dutch',
    'Polish',
    'Portuguese',
    'Romanian',
    'Russian',
    'Slovak',
    'Slovenian',
    'Swedish',
    'Chinese'
  ];
  
  
  Translator.prototype.languageCodes = [
    'BG',
    'CS',
    'DA',
    'DE',
    'EL',
    'EN',
    'ES',
    'ET',
    'FI',
    'FR',
    'HU',
    'IT',
    'JA',
    'LT',
    'LV',
    'NL',
    'PL',
    'PT',
    'RO',
    'RU',
    'SK',
    'SL',
    'SV',
    'ZH'
  ];
  


Translator.prototype.translateSelection = function (context) {

    var selection = context.selection;

    
    var title = selection.length == 0 ? 'Translate Current Page' : 'Translate Selection';

    if (selection.length == 0 ) {
        context.document.showMessage( 'Nothing selected. Switching to Page Translation.' );
    }

    var dialog = this.createWindow( context, title );

    var response = handleAlertResponse( dialog, dialog.runModal())
    var fromIndex = response[0];
    var toIndex = response[1];
    var constrain = response[2]

    var fromLanguage = this.languageCodes[fromIndex];
    var toLanguage = this.languageCodes[toIndex];

    if ( selection.length == 0 ) {
        selection = selectLayersOfTypeInContainer(context.document, "MSArtboardGroup", getCurrentPage(context) );
    }


    for ( var i = 0; i < selection.length; i++ ) {
        
        if ( isArtboard(selection[i]) ) {
            
            artboard = selection[i];
            ( sketchVersion > 45) ? artboard.select_byExpandingSelection(true, false) : artboard.select_byExtendingSelection(true, false);

            var symbolInstances = selectLayersOfTypeInContainer(context.document, "MSSymbolInstance", artboard);
            for ( var j = 0; j < symbolInstances.length; j++ ) {
                translateOverridesInSelection( symbolInstances[j], fromLanguage, toLanguage );
            }

            var textLayers = selectLayersOfTypeInContainer(context.document, "MSTextLayer", artboard);
            for ( var j = 0; j < textLayers.length; j++ ) {
                translateTextLayersInSelection( textLayers[j], fromLanguage, toLanguage )
            }

        }

        if ( isText(selection[i]) ) {
            translateTextLayersInSelection( selection[i], fromLanguage, toLanguage )
        }

        if ( isSymbolInstance(selection[i]) ) {
            translateOverridesInSelection( selection[i], fromLanguage, toLanguage );
        }

        if ( isSymbolMaster(selection[i]) ) {
            context.document.showMessage( 'Translation of symbol masters is not supported. Please translate the text layers in the symbol individually' );
        }

    }

}


Translator.prototype.translatePage = function (context) {
    
    var doc         = context.document;
    var thisPage    = [doc currentPage];
    var artboards   = [thisPage artboards];
    
    var dialog = this.createWindow( context,'Translate Current Page' );

    var response = handleAlertResponse( dialog, dialog.runModal())
    var fromIndex = response[0];
    var toIndex = response[1];
    var constrain = response[2]

    var fromLanguage = this.languageCodes[fromIndex];
    var toLanguage = this.languageCodes[toIndex];
    var page       = getCurrentPage(context);

    if (artboards.length === 0) {
        doc.showMessage('There are no artboards which contain text.')
        return;
    }

    var artboards = selectLayersOfTypeInContainer(context.document, "MSArtboardGroup", page);
    for ( var i = 0; i < artboards.length; i++ ) {

        artboard = artboards[i];

        var sketchVersion = BCSketchInfo.shared().metadata().appVersion;
        ( sketchVersion > 45) ? artboard.select_byExpandingSelection(true, false) : artboard.select_byExtendingSelection(true, false);

        var symbolInstances = selectLayersOfTypeInContainer(context.document, "MSSymbolInstance", artboard);
        for ( var j = 0; j < symbolInstances.length; j++ ) {
            translateOverridesInSelection( symbolInstances[j], fromLanguage, toLanguage );
        }

        var textLayers = selectLayersOfTypeInContainer(context.document, "MSTextLayer", artboard);
        for ( var j = 0; j < textLayers.length; j++ ) {
            translateTextLayersInSelection( textLayers[j], fromLanguage, toLanguage )
        }
    }
}

Translator.prototype.translateDocument = function (context) {

    var doc      = context.document;
    var pages    = [doc pages];

    var dialog    = this.createWindow( context, 'Translate Entire Document' );

    var response = handleAlertResponse( dialog, dialog.runModal())
    var fromIndex = response[0];
    var toIndex = response[1];
    var constrain = response[2]
    
    var fromLanguage = this.languageCodes[fromIndex];
    var toLanguage = this.languageCodes[toIndex];
    
    for ( var n = 0; n < pages.length; n++ ) {

        var thisPage  = pages[n];
        var artboards = [thisPage artboards];

        [doc setCurrentPage:thisPage];
        
        if (artboards.length === 0) {
            doc.showMessage('There are no artboards which contain text.')
            return;
        }

        var artboards = selectLayersOfTypeInContainer(context.document, "MSArtboardGroup", thisPage);
        
        for ( var i = 0; i < artboards.length; i++ ) {
    
            artboard = artboards[i];
    
            var sketchVersion = BCSketchInfo.shared().metadata().appVersion;
            ( sketchVersion > 45) ? artboard.select_byExpandingSelection(true, false) : artboard.select_byExtendingSelection(true, false);
    
            var symbolInstances = selectLayersOfTypeInContainer(context.document, "MSSymbolInstance", artboard);
            for ( var j = 0; j < symbolInstances.length; j++ ) {
                translateOverridesInSelection( symbolInstances[j], fromLanguage, toLanguage );
            }
    
            var textLayers = selectLayersOfTypeInContainer(context.document, "MSTextLayer", artboard);
            for ( var j = 0; j < textLayers.length; j++ ) {
                translateTextLayersInSelection( textLayers[j], fromLanguage, toLanguage )
            }
        }

    }
    
}


Translator.prototype.createWindow = function(context, title) {

    var apiKey = getOption('apiKey', '');
    var title = title || 'Sketch DeepL Translate';

    if ( apiKey.length == 0 ) {

        this.openKeyWindow( context )

    } else {

        var dialogWindow = COSAlertWindow.new();

        var doc = context.document;
        var page = [doc currentPage];
        var layers = context.selection.length == 0 ? [page children] : context.selection;
        var excerpt = '';

        function recursiveLoop( layers ) {      
    
            for ( var i = 0; i < layers.length; i++ ) {
                var currentLayer = layers[i];
                if ( isArtboard(currentLayer) || isGroup(currentLayer) ) {
                    recursiveLoop( currentLayer.layers() )
                }
                if ( isText(currentLayer) ) {
                    if ( excerpt == '' ) excerpt = currentLayer.stringValue();
                    if ( currentLayer.stringValue().split(' ').length > 5 ) {
                        excerpt = currentLayer.stringValue();
                        return;
                    }
                }
            }
        }
    
        recursiveLoop( layers, '' );
        
        var fromLanguage = excerpt ? detectLanguage( excerpt ) : '';
        // var fromLanguage = String( getOption('fromLanguage', '') );
        var fromLanguageSelect = createSelect( this.languageLabels );
        fromLanguageSelect.selectItemAtIndex( this.languageCodes.indexOf( fromLanguage ) )

        var toLanguage = String( getOption('toLanguage', '') );
        var toLanguageSelect = createSelect( this.languageLabels );
        toLanguageSelect.selectItemAtIndex( this.languageCodes.indexOf( toLanguage ) )

        dialogWindow.setMessageText(title);
        dialogWindow.setInformativeText('Please select origin and target language of your text translation.');

        dialogWindow.addAccessoryView( text( fontSizeLarge, 300, 10, 'From:')); // index 0
        dialogWindow.addAccessoryView(fromLanguageSelect); // index 1

        dialogWindow.addAccessoryView( text( fontSizeLarge, 300, 10, 'To:'));  // index 2
        dialogWindow.addAccessoryView(toLanguageSelect);  // index 3

        dialogWindow.addAccessoryView( text( fontSizeLarge, 300, 8, '')); // Spacing
        
        dialogWindow.addButtonWithTitle('OK');
        dialogWindow.addButtonWithTitle('Cancel');

    }

    dialogWindow.setIcon(NSImage.alloc().initByReferencingFile(context.plugin.urlForResourceNamed("DeepL.png").path()));
    return dialogWindow;
}


Translator.prototype.openKeyWindow = function(context) {
    var dialog   = this.createKeyWindow( context, 'Set DeepL API Key' );
    var response = handleKeyAlertResponse( dialog, dialog.runModal() );
}

Translator.prototype.createKeyWindow = function(context, title) {
    var apiKey = getOption('apiKey', '');
    var dialogWindow = COSAlertWindow.new();

    dialogWindow.setMessageText( title );
    dialogWindow.setInformativeText('Paste here your DeepL API Key:');
    dialogWindow.addTextFieldWithValue(apiKey.length == 0 ? '' : getOption('apiKey'));

    dialogWindow.addAccessoryView( button( fontSizeSmall, 300, 20, 'Get your free DeepL API Key', 'https://www.deepl.com/pro#developer'));
    dialogWindow.addAccessoryView( text( fontSizeSmall, 300, 40, 'Can be used for max. 500,000 characters/month\n'));

    var apiKeyTextBox = dialogWindow.viewAtIndex(0);
    
    dialogWindow.alert().window().setInitialFirstResponder(apiKeyTextBox);
    
    dialogWindow.addButtonWithTitle('OK');
    dialogWindow.addButtonWithTitle('Cancel');
    
    dialogWindow.setIcon(NSImage.alloc().initByReferencingFile(context.plugin.urlForResourceNamed("DeepL.png").path()));
    return dialogWindow;
}


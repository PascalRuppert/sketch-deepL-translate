@import "translator.js";

function runSelectionTranslation (context) {
  var translator = new Translator();
  translator.translateSelection(context);
}

function runPageTranslation (context) {
  var translator = new Translator();
  translator.translatePage(context);
}

function runDocumentTranslation (context) {
  var translator = new Translator();
  translator.translateDocument(context);
}

function runSetApiKey (context) {
  var translator = new Translator();
  translator.openKeyWindow(context);
}